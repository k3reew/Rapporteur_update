from pathlib import Path
import json,csv,statistics,collections
W=Path(__file__).resolve().parent
key=json.loads((W/'assessment-key.json').read_text());grades=json.loads((W/'assessments.json').read_text())
by_run={(v['talk'],v['mode']):rid for rid,v in key.items()}
rows=[]
for p in sorted((W/'study/runs').glob('*.json')):
 d=json.loads(p.read_text());r={'talk':d['talk'],'mode':d['mode'],'state':d['state'],'seconds':round(d['seconds'],4),'calls':d['calls'],'error':d.get('error','')}
 rid=by_run[(r['talk'],r['mode'])]
 if d['state']=='completed':
  a=json.loads((W/'assessment'/f'{rid}.json').read_text());g=grades[rid]
  citations=[e for line in a['lines'] for e in line['evidence']]
  r.update({'assessment':rid,'p_num':g['line_status'].count('supported'),'p_den':len(g['line_status']),'g_num':len(g['covered_ids']),'g_den':len(a['gold']),'l_num':sum(e['valid'] for e in citations),'l_den':len(citations),'partial':len(g['partial_ids'])})
  for m in ('p','g','l'):r[m]=r[m+'_num']/r[m+'_den'] if r[m+'_den'] else None
 rows.append(r)
assert len(rows)==37
assert collections.Counter(r['mode'] for r in rows)=={'A':16,'B':16,'C':5}
assert len([r for r in rows if r['state']=='completed'])==len(grades)==25

def agg(selected):
 complete=[r for r in selected if r['state']=='completed'];out={'assigned':len(selected),'completed':len(complete),'states':dict(collections.Counter(r['state'] for r in selected)),'all_seconds':round(sum(r['seconds'] for r in selected),3),'median_seconds_all':statistics.median(r['seconds'] for r in selected),'calls':sum(r['calls'] for r in selected)}
 for m in ('p','g','l'):
  n=sum(r[m+'_num'] for r in complete);den=sum(r[m+'_den'] for r in complete)
  out[m]={'num':n,'den':den,'micro':n/den if den else None,'macro':statistics.mean(r[m] for r in complete if r[m] is not None) if complete else None}
 return out
summary={'by_mode':{m:agg([r for r in rows if r['mode']==m]) for m in 'ABC'},'pairs':{}}
lookup={(r['talk'],r['mode']):r for r in rows}
for left,right in [('A','B'),('B','C')]:
 talks=[t for t in sorted({r['talk'] for r in rows}) if (t,left) in lookup and (t,right) in lookup and all(lookup[(t,m)]['state']=='completed' for m in (left,right))]
 pair={'talks':talks,'n':len(talks),'left':agg([lookup[(t,left)] for t in talks]),'right':agg([lookup[(t,right)] for t in talks])}
 pair['mean_difference_right_minus_left']={m:statistics.mean(lookup[(t,right)][m]-lookup[(t,left)][m] for t in talks) for m in ('p','g','l','seconds')}
 pair['median_difference_right_minus_left']={m:statistics.median(lookup[(t,right)][m]-lookup[(t,left)][m] for t in talks) for m in ('p','g','l','seconds')}
 summary['pairs'][left+right]=pair
for m in 'ABC':
 failures=[r for r in rows if r['mode']==m and r['state']!='completed']
 summary['by_mode'][m]['failure_types']=dict(collections.Counter('empty' if r['state']=='empty' else 'infrastructure_http500' if '500:' in r['error'] else 'output_limit' if 'оборван' in r['error'] else 'invalid_labels' if 'метки' in r['error'] else 'other' for r in failures))
(W/'metrics.json').write_text(json.dumps({'rows':rows,'summary':summary},ensure_ascii=False,indent=2))
with (W/'metrics.csv').open('w') as f:
 cols=['talk','mode','state','seconds','calls','p_num','p_den','g_num','g_den','l_num','l_den','partial','p','g','l','assessment','error'];writer=csv.DictWriter(f,fieldnames=cols);writer.writeheader();writer.writerows(rows)
print(json.dumps(summary,ensure_ascii=False,indent=2))
