"""Контрольные синтетические примеры для верификатора f07a0d0."""
import hashlib,json,platform
from pathlib import Path
from tests.test_verify import _verify, _fact, RESULTS_SLIDE, VLM
from rapporteur.summarize.quotes import QuoteConfig

cases=[
 ('K1','Точная цитата','Точность выросла до 94,5 %.','S1','точность выросла до 94,5 %','verified',None),
 ('K2','Подмена числа в цитате','Точность выросла до 84,5 %.','S1','точность выросла до 84,5 %','rejected','number_mismatch'),
 ('K3','Пропуск отрицания в цитате','Время обучения увеличилось.','S1','Время обучения увеличилось при росте выборки вдвое','rejected','negation_mismatch'),
 ('K4','Неизвестная метка','Точность выросла до 94,5 %.','S999','точность выросла до 94,5 %','rejected','label_not_found'),
 ('K5','Опора только на визуальное описание','На схеме три узла кластера.','V3',VLM,'needs_human',None),
 ('K6','Искажён смысл утверждения при точной цитате','Время обучения увеличилось при росте выборки вдвое.','S1','Время обучения не увеличилось при росте выборки вдвое','verified',None),
]
rows=[]
for key,description,text,label,quote,status,reason in cases:
 claim=_verify(_fact(text,(label,quote)))[0]
 actual=claim.status.value
 rejection=claim.rejected_evidence[0].reason.value if claim.rejected_evidence else None
 assert actual==status,(key,actual,status)
 assert rejection==reason,(key,rejection,reason)
 score=claim.evidence[0].match_score if claim.evidence else claim.rejected_evidence[0].best_score
 rows.append({'id':key,'description':description,'claim':text,'label':label,'quote':quote,'status':actual,'rejection':rejection,'match_score':score})
result={'date':'2026-11-15','commit':'f07a0d07e08c413b30c383bab37a4920ed861c00','python':platform.python_version(),'model_invoked':False,'data_kind':'synthetic_fixtures','fixture':'tests/test_verify.py','source_text':RESULTS_SLIDE,'quote_config':QuoteConfig().model_dump(),'checks':rows,'source_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['tests/test_verify.py','src/rapporteur/summarize/verify.py','src/rapporteur/summarize/quotes.py']}}
Path('.local/article-publication/controls.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for r in rows:print(r['id'],r['status'],r['rejection'],r['match_score'])
