from math import atan2, cos, sin
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

out = Path(__file__).parent / "method.png"
width, height = 1540, 457
im = Image.new("RGB", (width, height), "white")
draw = ImageDraw.Draw(im)
font_path = "/usr/share/fonts/truetype/liberation"
font = ImageFont.truetype(f"{font_path}/LiberationSans-Regular.ttf", 31)
bold = ImageFont.truetype(f"{font_path}/LiberationSans-Bold.ttf", 34)
ink, accent, line = "#172337", "#24465F", "#657E93"

def box(rect, label, fill, face=font):
    draw.rounded_rectangle(rect, radius=9, fill=fill, outline=line, width=2)
    left, top, right, bottom = rect
    draw.multiline_text(((left+right)/2,(top+bottom)/2), label, align="center",
                        anchor="mm", fill=ink, font=face, spacing=3)

def arrow(points):
    draw.line(points, fill=line, width=4)
    (xa,ya),(xb,yb) = points[-2:]
    angle=atan2(yb-ya,xb-xa)
    tip=[(xb,yb), (xb-14*cos(angle+0.48), yb-14*sin(angle+0.48)),
         (xb-14*cos(angle-0.48), yb-14*sin(angle-0.48))]
    draw.polygon(tip, fill=line)

cols=[(38, 477), (550, 989), (1062, 1501)]
inputs=[("Аудио и видео", "Выделение речи\nWhisper · таймкоды"),
        ("Презентации и изображения", "Текст и OCR\nОписание графиков и схем"),
        ("Документы и заметки", "Извлечение текста\nСтраницы и позиции")]
for (left,right),(source,process) in zip(cols, inputs, strict=True):
    center=(left+right)//2
    box((left, 8, right, 71), source, "#F0F5F9")
    arrow([(center,71),(center,92)])
    box((left, 92, right, 181), process, "white")
    arrow([(center,181),(center,221)])

box((38,221,1501,321), "Подтверждённый реестр и привязки\nПакет фрагментов доклада с локаторами", "#EDF3F7", bold)
arrow([(770,321),(770,346),(200,346),(200,370)])
outputs=["Извлечение\nфактов и цитат", "Проверка\nцитат", "Сводка и проверка\nоператором", "Рекомендации\nи выпуск справки"]
for i, label in enumerate(outputs):
    left=38+375*i
    box((left,370,left+337,450),label,"white")
    if i<3:
        arrow([(left+337,410),(left+375,410)])
im.save(out,dpi=(240,240))
assert im.size==(1540,457)
