from pathlib import Path
import json,random,hashlib
from rapporteur.contracts import TalkFragmentPack,FactsDraft
from rapporteur.summarize.verify import _facts_in_order
from rapporteur.summarize.quotes import QuoteConfig,match_quote,search_form
from rapidfuzz import fuzz
W=Path('/app/.local/article-publication');ST=W/'study';out=W/'assessment';out.mkdir(exist_ok=True)
plan=json.loads((ST/'plan.json').read_text())['runs'];random.Random(86420).shuffle(plan)
key={f'R{i+1:02d}':{'talk':talk,'mode':mode} for i,(talk,mode) in enumerate(plan)}
(W/'assessment-key.json').write_text(json.dumps(key,ensure_ascii=False,indent=2))
refs=json.loads((W/'reference-reviewed.json').read_text())['items']
completed=[]
def excerpt(quote,text):
 wanted=search_form(quote);source=search_form(text)
 if not wanted.text or not source.text:return text[:800]
 alignment=fuzz.partial_ratio_alignment(wanted.text,source.text)
 if not alignment:return text[:800]
 a,b=source.source_span(alignment.dest_start,alignment.dest_end)
 return text[max(0,a-100):min(len(text),b+100)]
for rid,entry in key.items():
 path=ST/'runs'/f"{entry['talk']}-{entry['mode']}.json"
 if not path.exists():continue
 result=json.loads(path.read_text())
 if result['state']!='completed':continue
 pack=TalkFragmentPack.model_validate_json((ST/'packs'/(entry['talk']+'.json')).read_text())
 if entry['mode']=='C':pack=pack.model_copy(update={'fragments':[f for f in pack.fragments if f.kind.value=='transcript']})
 by_label=pack.by_label();claims={c['key']:c for c in result['claims']}
 raw={f'c{i+1}':fact for i,(_,fact) in enumerate(_facts_in_order(FactsDraft.model_validate(result['facts'])))}
 lines=[]
 for i,line in enumerate(result['sentences']+result['conclusions'],1):
  evidence=[]
  for cid in line['claim_ids']:
   claim=claims.get(cid)
   if not claim:
    evidence.append({'id':f'L{i}E{len(evidence)+1}','claim':cid,'label':None,'quote':None,'source':None,'valid':False,'reason':'unknown_claim'});continue
   items=[e.model_dump(mode='json') for e in raw[cid].evidence] if entry['mode']=='A' else claim['evidence']
   for item in items:
    label,quote=item['label'],item['quote'];fragment=by_label.get(label)
    match=match_quote(quote,fragment.text,QuoteConfig()) if fragment else None
    valid=fragment is not None and match.rejection is None
    shown=fragment
    if shown is None:
     shown=max(pack.fragments,key=lambda f:fuzz.partial_ratio(quote,f.text))
    evidence.append({'id':f'L{i}E{len(evidence)+1}','claim':claim['text'],'label':label,'quote':quote,'source_label':shown.label,'source_origin':shown.origin.value,'source_locator':shown.locator.model_dump(mode='json'),'source':excerpt(quote,shown.text),'valid':valid,'reason':None if valid else match.rejection.value if match else 'label_not_found'})
  lines.append({'id':f'L{i}','text':line['text'],'evidence':evidence})
 data={'id':rid,'talk':entry['talk'],'gold':[{'id':r['id'],'fact':r['fact']} for r in refs if r['talk']==entry['talk']],'lines':lines,'scope':'indexed_asr_and_pdf_with_AI_assisted_assessment'}
 (out/(rid+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
 text=[rid+' '+entry['talk'],'Эталонные тезисы']+[r['id']+' '+r['fact'] for r in data['gold']]
 for line in lines:
  text.append('\n'+line['id']+' '+line['text'])
  for e in line['evidence']:
   text.append('  '+e['id']+' '+str(e.get('label'))+' Цитата '+str(e.get('quote'))+'\n  Источник '+str(e.get('source_label'))+' '+str(e.get('source')))
 (out/(rid+'.txt')).write_text('\n'.join(text))
 completed.append(rid)
print('Assessment records',len(completed),' '.join(completed))
