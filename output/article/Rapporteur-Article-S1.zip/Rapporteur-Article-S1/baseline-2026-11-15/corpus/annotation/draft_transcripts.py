import json
from pathlib import Path
from faster_whisper import BatchedInferencePipeline, WhisperModel

output = Path("/annotation")
model = WhisperModel("/models/asr", device="cuda", compute_type="int8_float16", local_files_only=True)
pipeline = BatchedInferencePipeline(model=model)
paths = sorted(Path("/corpus").glob("*/*.mp4"), key=lambda p:(p.parent.name not in {"03A","03B","04A","04B"},p.parent.name,p.name))
for path in paths:
    target = output / f"{path.parent.name}-{path.stem}.jsonl"
    if target.is_file():
        continue
    print("start", path, flush=True)
    segments, _ = pipeline.transcribe(str(path), language="ru", beam_size=1, batch_size=4,
                                      without_timestamps=True, vad_filter=True)
    temporary = target.with_suffix(".partial")
    with temporary.open("w") as f:
        for s in segments:
            f.write(json.dumps(dict(start=s.start, end=s.end, text=s.text.strip()), ensure_ascii=False)+"\n")
            f.flush()
    temporary.rename(target)
    print("done", target, flush=True)
