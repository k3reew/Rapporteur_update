# Паспорт русскоязычного корпуса

Дата сверки страниц файлов — 15 ноября 2026 года. В основной части 16 записей Вики-конференций 2014 и 2026 годов и пять PDF-презентаций. Два PDF 2020 года предназначены для тренировки. [Программа 2014](https://ru.wikimedia.org/wiki/Вики-конференция_2014/Программа) · [Архив 2026](https://commons.wikimedia.org/wiki/Category:Russian_Wikipedia_Discord_Wiki-Conference_2026) · [Программа 2020](https://ru.wikimedia.org/wiki/Вики-конференция_2020/Программа)

Каждый пакет содержит две отдельные записи и краткую программу с именами файлов. В парах сопоставлялись событие, длительность и наличие отдельных презентаций. Слайды включены при наличии доступного файла с установленными условиями использования. В пакетах 2014 года отдельные презентации не приложены. Программы составлены для пилота на основе публичных метаданных. Полный реестр с SHA-256, размерами, версиями страниц и адресами скачивания находится в [corpus.csv](corpus.csv). Контрольные суммы программ, положений и остальных файлов находятся в [SHA256SUMS](SHA256SUMS).

## Пакеты

| Пара | Пакет | Событие | Записи суммарно | Слайды PDF |
| --- | --- | --- | --- | ---: |
| 01 | 01A | 2014 | 63:14 | 0 |
| 01 | 01B | 2014 | 62:43 | 0 |
| 02 | 02A | 2014 | 53:01 | 0 |
| 02 | 02B | 2014 | 54:05 | 0 |
| 03 | 03A | 2026 | 25:38 | 1 |
| 03 | 03B | 2026 | 25:59 | 1 |
| 04 | 04A | 2026 | 28:13 | 1 |
| 04 | 04B | 2026 | 34:54 | 2 |

Для пары 04 отдельно учитывать разницу в длительности и числе презентаций. Для записи 03B/doklad-1.mp4 описание на странице источника отмечает помехи на 05:10–11:18. Разметчик указывает неразборчивые интервалы и опирается на верифицируемые части материала.

## Атрибуция файлов и преобразования

WebM 480p VP9 с Wikimedia Commons → MP4 H.264/AAC. FFmpeg 7.1.5, libx264 ultrafast CRF 29, yuv420p, AAC 128 кбит/с, без нарезки, faststart.

Приведённые ниже условия относятся к каждому файлу. Для производных MP4 сохранена лицензия соответствующей исходной записи. При повторном распространении сохраняйте атрибуцию и указание на преобразование.

| Файл | Название | Автор материала по странице источника | Лицензия и источник |
| --- | --- | --- | --- |
| `pakety/01A/doklad-1.mp4` | Общественное достояние | Алексей Аларгус | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Wikiconference_in_Moscow_day_1_part_3.webm&oldid=1135469349) |
| `pakety/01A/doklad-2.mp4` | Добротные статьи — что это такое? | Алексей Аларгус | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Wikiconference_in_Moscow_day_2_part_1.webm&oldid=1000392000) |
| `pakety/01B/doklad-1.mp4` | Большая российская энциклопедия и проект создания энциклопедического портала «Знание» | Алексей Аларгус | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Wikiconference_in_Moscow_day_1_part_5.webm&oldid=999905258) |
| `pakety/01B/doklad-2.mp4` | Путеводитель в стиле wiki | Алексей Аларгус | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Wikiconference_in_Moscow_day_2_part_4.webm&oldid=999927370) |
| `pakety/02A/doklad-1.mp4` | Интеллектуальная собственность | Алексей Аларгус | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Wikiconference_in_Moscow_day_1_part_4.webm&oldid=1270455307) |
| `pakety/02A/doklad-2.mp4` | Взаимодействие Википедии и крупной компании | Алексей Аларгус | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Wikiconference_in_Moscow_day_2_part_5.webm&oldid=999931863) |
| `pakety/02B/doklad-1.mp4` | Черниговские вики-экспедиции | Алексей Аларгус | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Wikiconference_in_Moscow_day_1_part_10.webm&oldid=999868430) |
| `pakety/02B/doklad-2.mp4` | Что за карта OSM | Алексей Аларгус | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Wikiconference_in_Moscow_day_1_part_8.webm&oldid=999930082) |
| `pakety/03A/doklad-1.mp4` | Проекты в Википедии | Участники сервера Discord, согласившиеся на CC BY-SA 4.0 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:2026_Kylaix_presentation_on_projects_in_Russian_Wikipedia_without_discussion.webm&oldid=1269737322) |
| `pakety/03A/doklad-1.pdf` | Проекты в Википедии · слайды | Kylaix | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:WikiConf-2026._Wikiprojects.pdf&oldid=1277861164) |
| `pakety/03A/doklad-2.mp4` | Использование источников при написании статей на исторические темы | Участники сервера Discord, согласившиеся на CC BY-SA 4.0 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:2026_Nikolay_Omonov_presentation_on_using_sources_for_the_historical_theme_without_discussion.webm&oldid=1269738351) |
| `pakety/03B/doklad-1.mp4` | О вымирании Рувики | Участники сервера Discord, согласившиеся на CC BY-SA 4.0 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:2026_Nikolay_Omonov_presentation_on_Russian_Wikipedia_decline_without_discussion.webm&oldid=1269738325) |
| `pakety/03B/doklad-2.mp4` | Волонтёры и система VRT | Участники сервера Discord, согласившиеся на CC BY-SA 4.0 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:2026_S.Marchenko_presentation_on_VRT_system_without_discussion.webm&oldid=1269739329) |
| `pakety/03B/doklad-2.pdf` | Волонтёры и система VRT · слайды | S.Marchenko | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Report_on_VRT.pdf&oldid=1255519484) |
| `pakety/04A/doklad-1.mp4` | Викиучебник | Участники сервера Discord, согласившиеся на CC BY-SA 4.0 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:2026_Kylaix_presentation_on_Russian_Wikibooks_without_discussion.webm&oldid=1269737356) |
| `pakety/04A/doklad-1.pdf` | Викиучебник · слайды | Kylaix | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:WikiConf-2026._Wikibooks.pdf&oldid=1256264865) |
| `pakety/04A/doklad-2.mp4` | О POV-пушинге | Участники сервера Discord, согласившиеся на CC BY-SA 4.0 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:2026_Nikolay_Omonov_presentation_on_POV_pushing_without_discussion.webm&oldid=1269738302) |
| `pakety/04B/doklad-1.mp4` | Викиверситет | Участники сервера Discord, согласившиеся на CC BY-SA 4.0 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:2026_Kylaix_presentation_on_Russian_Wikiversity_without_discussion.webm&oldid=1269737392) |
| `pakety/04B/doklad-1.pdf` | Викиверситет · слайды | Kylaix | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:WikiConf-2026._Wikiversity.pdf&oldid=1256264997) |
| `pakety/04B/doklad-2.mp4` | Как писать статьи по естественнонаучным темам | Участники сервера Discord, согласившиеся на CC BY-SA 4.0 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:2026_Vallastro_presentation_on_writing_articles_on_scientific_themes_without_discussion.webm&oldid=1269744660) |
| `pakety/04B/doklad-2.pdf` | Как писать статьи по естественнонаучным темам · слайды | Vallastro | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:Ruwiki_conference_2026_-_natural_sciences.pdf&oldid=1264410252) |
| `trenirovka/TA.pdf` | Викимедиа для цифровой трансформации социума | Frhdkazan | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:%D0%92%D0%B8%D0%BA%D0%B8%D0%BC%D0%B5%D0%B4%D0%B8%D0%B0_%D0%B4%D0%BB%D1%8F_%D1%86%D0%B8%D1%84%D1%80%D0%BE%D0%B2%D0%BE%D0%B9_%D1%82%D1%80%D0%B0%D0%BD%D1%81%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D0%B8_%D1%81%D0%BE%D1%86%D0%B8%D1%83%D0%BC%D0%B0.pdf&oldid=630852449) |
| `trenirovka/TB.pdf` | Региональные разделы Википедии — достижения и вызовы | Soul Train | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [страница файла](https://commons.wikimedia.org/w/index.php?title=File:%D0%A0%D0%B5%D0%B3%D0%B8%D0%BE%D0%BD%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D0%B5_%D1%80%D0%B0%D0%B7%D0%B4%D0%B5%D0%BB%D1%8B_%D0%92%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D0%B8_-_%D0%94%D0%BE%D1%81%D1%82%D0%B8%D0%B6%D0%B5%D0%BD%D0%B8%D1%8F_%D0%B8_%D0%B2%D1%8B%D0%B7%D0%BE%D0%B2%D1%8B_2020.pdf&oldid=475323372) |

## Техническая проверка

В контейнере `rapporteur-dev:local` на исходниках коммита `f07a0d07e08c413b30c383bab37a4920ed861c00` проверены типы 16 записей, восьми программ и семи презентаций, включая тренировочные. Для обоих учебных положений подтверждено извлечение трёх отдельных пунктов с локаторами `p1.1`, `p2.1`, `p3.1`. Форматы и длительность файлов сохранены в [протоколе проверки входных материалов](proverka-korpusa.json).
