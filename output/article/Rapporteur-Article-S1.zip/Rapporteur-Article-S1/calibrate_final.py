from pathlib import Path
from dataclasses import asdict
import json,os,time
from rapporteur.contracts import FactsDraft,TalkFragmentPack,ModelProfile
from rapporteur.llm.client import OllamaClient,ChatRequest,Message
from rapporteur.summarize.facts import _facts_schema,_facts_problems,_review_facts,FactsConfig
from rapporteur.summarize.pack import context_fragments
W=Path('/app/.local/article-publication-v2');OUT=W/'diagnostic-final';OUT.mkdir(exist_ok=True)
class Recording:
 def __init__(self,prefix):self.client=OllamaClient(os.environ['OLLAMA_URL']);self.prefix=prefix;self.number=0
 def chat(self,request):
  self.number+=1;stem=self.prefix+f'-{self.number:03d}'
  (OUT/(stem+'-request.json')).write_text(json.dumps(asdict(request),ensure_ascii=False,indent=2))
  response=self.client.chat(request)
  (OUT/(stem+'-response.json')).write_text(json.dumps(asdict(response),ensure_ascii=False,indent=2))
  return response
pack=TalkFragmentPack.model_validate_json((W/'study/packs/04B-doklad-2.json').read_text())
pack=pack.model_copy(update={'fragments':[f for f in pack.fragments if f.kind.value=='transcript']})
d=json.loads((W/'study/calls/04B-doklad-2-C-001-request.json').read_text());d['schema']=_facts_schema(pack)
request=ChatRequest(**{**d,'messages':tuple(Message(m['role'],m['content']) for m in d['messages'])})
start=time.monotonic();response=Recording('schema').chat(request);value=FactsDraft.model_validate_json(response.content)
assert response.done_reason!='length';assert not _facts_problems(value,pack)
results={'schema':{'seconds':time.monotonic()-start,'tokens':response.completion_tokens,'conclusions':len(value.conclusions),'reason':value.conclusions_absent_reason}}
pack=TalkFragmentPack.model_validate_json((W/'study/packs/03A-doklad-1.json').read_text())
parts=[FactsDraft.model_validate_json(json.loads((W/f'study/calls/03A-doklad-1-B-{n:03d}-response.json').read_text())['content']) for n in [2,4]]
evidence=[e for part in parts for field in ['problem','methods','results','conclusions','listener_remarks'] for f in ([getattr(part,field)] if field=='problem' and part.problem else [] if field=='problem' else getattr(part,field)) for e in f.evidence]
sources=pack.model_copy(update={'fragments':context_fragments(pack,evidence)})
profile=ModelProfile.model_validate_json((W/'study/profile.json').read_text());start=time.monotonic()
result=_review_facts(Recording('merge'),sources,FactsConfig(profile=profile),'\n'.join(p.model_dump_json() for p in parts))
(OUT/'merged-facts.json').write_text(result.model_dump_json(indent=2))
results['merge']={'seconds':time.monotonic()-start,'attempts':result.attempts,'methods':[f.text for f in result.facts.methods],'results':[f.text for f in result.facts.results],'conclusions':[f.text for f in result.facts.conclusions]}
(OUT/'result.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
