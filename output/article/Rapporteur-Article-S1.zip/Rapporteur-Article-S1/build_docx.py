from pathlib import Path
import re,json
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
W=Path(__file__).resolve().parent
OUT=Path('/home/kirill/Documents/Codex/2026-11-15/yf/outputs/Rapporteur-Article-Revised.docx')
FIG=W/'figures/method.png'
d=Document();sec=d.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=Inches(.72);sec.bottom_margin=Inches(.7);sec.left_margin=Inches(.85);sec.right_margin=Inches(.85)
normal=d.styles['Normal'];normal.font.name='Liberation Serif';normal.font.size=Pt(11.5)
normal.paragraph_format.line_spacing=1.08;normal.paragraph_format.space_after=Pt(5)
for name,size in [('Title',16),('Heading 1',13),('Heading 2',12)]:
 st=d.styles[name];st.font.name='Liberation Serif';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0);st.font.bold=True
 st.paragraph_format.space_before=Pt(11);st.paragraph_format.space_after=Pt(5);st.paragraph_format.keep_with_next=True
st=d.styles['Caption'];st.font.name='Liberation Serif';st.font.size=Pt(10.5);st.font.color.rgb=RGBColor(0,0,0);st.paragraph_format.space_after=Pt(6)
# Remove inherited template decorations and theme fonts for a journal manuscript.
for style in d.styles:
 for border in list(style.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
 if style.name in ['Normal','Title','Heading 1','Heading 2','Caption']:
  rf=style.element.get_or_add_rPr().get_or_add_rFonts()
  for attr in list(rf.attrib):
   if 'Theme' in attr:del rf.attrib[attr]
  for script in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+script),'Liberation Serif')
# Plain page number preserves manuscript navigation without a running title.
p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run();field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');r._r.addnext(field)
core=d.core_properties;core.title='Формирование аналитических справок по мультимодальным материалам конференций с прослеживаемыми утверждениями';core.author='';core.subject='Метод и локальный сравнительный пилот';core.keywords='Репортёр, конференции, реферирование, прослеживаемость';core.comments=''

def inline(p,text):
 for part in re.split(r'(\*\*.*?\*\*)',text):
  r=p.add_run(part[2:-2] if part.startswith('**') else part);r.bold=part.startswith('**')
 if '[[' in text:
  for r in p.runs:r.font.color.rgb=RGBColor.from_string('7A2D20')

def table(lines):
 values=[[s.strip() for s in line.strip().strip('|').split('|')] for line in lines if not re.fullmatch(r'[\s|:-]+',line)]
 cols=len(values[0]);t=d.add_table(rows=0,cols=cols);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 widths=[.7,.8,1.25,1.25,1.25,1.55] if cols==6 else [.8,2.35,.65,2.35,.65]
 assert abs(sum(widths)-6.8)<.001
 for col,width in zip(t.columns,widths):col.width=Inches(width)
 for i,row in enumerate(values):
  cells=t.add_row().cells
  trpr=t.rows[-1]._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
  if i==0:
   repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
  for cell,text,width in zip(cells,row,widths):
   cell.width=Inches(width);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   p=cell.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.LEFT if cell is cells[0] else WD_ALIGN_PARAGRAPH.CENTER
   p.paragraph_format.space_after=Pt(4);p.paragraph_format.space_before=Pt(4);p.paragraph_format.line_spacing=1.0
   run=p.add_run(text);run.font.size=Pt(10);run.bold=i==0
   pr=cell._tc.get_or_add_tcPr()
   margins=OxmlElement('w:tcMar')
   for side in ('top','left','bottom','right'):
    e=OxmlElement('w:'+side);e.set(qn('w:w'),'65');e.set(qn('w:type'),'dxa');margins.append(e)
   pr.append(margins)
   if i==0:
    shd=OxmlElement('w:shd');shd.set(qn('w:fill'),'EEEEEE');pr.append(shd)
   borders=OxmlElement('w:tcBorders')
   for side in ('top','bottom','left','right'):
    e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'B0B0B0');borders.append(e)
   pr.append(borders)
 d.add_paragraph().paragraph_format.space_after=Pt(0)

text=(W/'manuscript.md').read_text();blocks=text.split('\n\n');bibliography=False
for b in blocks:
 b=b.strip()
 if not b:continue
 if b=='[[FIGURE_METHOD]]':
  p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
  drawing=p.add_run().add_picture(str(FIG),width=Inches(6.6));props=drawing._inline.docPr;props.set('descr','Поток от записей, слайдов и документов через пакеты фрагментов, факты и цитаты к контекстной сверке, сводке, смысловому критику, проверке оператором и справке.')
 elif b.startswith('|'):table(b.splitlines())
 elif b.startswith('# '):
  p=d.add_paragraph(b[2:],'Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 elif b.startswith('### '):d.add_paragraph(b[4:],'Heading 2')
 elif b.startswith('## '):
  d.add_paragraph(b[3:],'Heading 1');bibliography=b[3:]=='Библиография'
 elif re.match(r'^(Таблица|Рисунок) \d+ —',b):
  p=d.add_paragraph(b,'Caption');p.paragraph_format.keep_with_next=b.startswith('Таблица ')
 else:
  p=d.add_paragraph();inline(p,b)
  p.paragraph_format.widow_control=True
  if b.startswith('Редакция для'):
   p.alignment=WD_ALIGN_PARAGRAPH.CENTER
   for r in p.runs:r.italic=True;r.font.size=Pt(10);r.font.color.rgb=RGBColor.from_string('555555')
  elif bibliography:
   p.paragraph_format.keep_together=True;p.paragraph_format.space_after=Pt(5)
   for r in p.runs:r.font.size=Pt(10.5)
  elif b.startswith('[['):p.paragraph_format.keep_together=True
  else:p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
OUT.parent.mkdir(parents=True,exist_ok=True);d.save(OUT)
assert len(d.tables)==3
assert len(d.inline_shapes)==1
assert all(len(t.rows)>1 for t in d.tables)
print(OUT,OUT.stat().st_size,'bytes')
